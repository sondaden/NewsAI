package com.example.myapplication.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.model.NewsArticle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SavedViewModel : ViewModel() {
    private val _savedArticles = MutableStateFlow<List<NewsArticle>>(emptyList())
    val savedArticles: StateFlow<List<NewsArticle>> = _savedArticles.asStateFlow()

    private val _savedTopics = MutableStateFlow<List<String>>(emptyList())
    val savedTopics: StateFlow<List<String>> = _savedTopics.asStateFlow()

    private val _savedSources = MutableStateFlow<List<String>>(emptyList())
    val savedSources: StateFlow<List<String>> = _savedSources.asStateFlow()

    init {
        fetchSavedArticles()
        fetchSavedTopics()
        fetchSavedSources()
    }

    private fun fetchSavedArticles() {
        viewModelScope.launch {
            // In a real app, fetch saved articles from repository
            _savedArticles.value = getSampleArticles()
        }
    }

    private fun fetchSavedTopics() {
        viewModelScope.launch {
            _savedTopics.value = listOf("Công nghệ", "Khoa học", "Thể thao", "Giải trí")
        }
    }

    private fun fetchSavedSources() {
        viewModelScope.launch {
            _savedSources.value = listOf("VnExpress", "Tuổi Trẻ", "TechCrunch", "The Verge")
        }
    }

    private fun getSampleArticles(): List<NewsArticle> {
        return listOf(
            NewsArticle(
                id = "1",
                title = "Bài viết đã lưu số 1",
                content = "Nội dung bài viết đã lưu số 1",
                imageUrl = "https://placekitten.com/200/200",
                publishedAt = "2 giờ trước",
                source = "VnExpress",
                author = listOf("Nguyễn Văn A"),
                category = listOf("Công nghệ")
            ),
            NewsArticle(
                id = "2",
                title = "Bài viết đã lưu số 2",
                content = "Nội dung bài viết đã lưu số 2",
                imageUrl = "https://placekitten.com/201/201",
                publishedAt = "5 giờ trước",
                source = "Tuổi Trẻ",
                author = listOf("Trần Thị B"),
                category = listOf("Khoa học")
            )
        )
    }
}