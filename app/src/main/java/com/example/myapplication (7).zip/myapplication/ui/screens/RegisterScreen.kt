package com.example.myapplication.ui.screens

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.compose.runtime.livedata.observeAsState
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myapplication.viewmodel.AuthViewModel

@Composable
fun RegisterScreen(navController: NavController, authViewModel: AuthViewModel = viewModel()) {
    val context = LocalContext.current
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    val registerState by authViewModel.registerState.observeAsState()

    var usernameError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var confirmPasswordError by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Đăng ký", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it; usernameError = null },
            label = { Text("Tên người dùng") },
            isError = usernameError != null
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it; emailError = null },
            label = { Text("Email") },
            isError = emailError != null
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it; passwordError = null },
            label = { Text("Mật khẩu") },
            isError = passwordError != null
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it; confirmPasswordError = null },
            label = { Text("Xác nhận mật khẩu") },
            isError = confirmPasswordError != null
        )
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                // Kiểm tra lỗi đầu vào
                usernameError = if (username.isBlank()) "Tên người dùng không được để trống!" else null
                emailError = when {
                    email.isBlank() -> "Email không được để trống!"
                    !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() -> "Email không hợp lệ!"
                    else -> null
                }
                passwordError = when {
                    password.length < 8 || !password.matches(".*[a-zA-Z].*".toRegex()) || !password.matches(".*\\d.*".toRegex()) -> "Mật khẩu phải có ít nhất 8 ký tự gồm cả chữ và số!"
                    else -> null
                }
                confirmPasswordError = if (password != confirmPassword) "Mật khẩu xác nhận không khớp!" else null

                // Log lỗi
                Log.d("Register", "usernameError: $usernameError")
                Log.d("Register", "emailError: $emailError")
                Log.d("Register", "passwordError: $passwordError")
                Log.d("Register", "confirmPasswordError: $confirmPasswordError")

                if (usernameError == null && emailError == null && passwordError == null && confirmPasswordError == null) {
                    authViewModel.checkEmailExists(email) { exists ->
                        if (exists) {
                            Log.d("Register", "Email đã tồn tại!")
                            emailError = "Email đã được đăng ký!"
                        } else {
                            Log.d("Register", "Bắt đầu đăng ký với tên: $username")
                            authViewModel.registerUser(email, password, username, avatarUrl = null)
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Đăng ký")
        }

        Spacer(modifier = Modifier.height(16.dp))
        TextButton(onClick = { navController.navigate("login") }) {
            Text("Đã có tài khoản? Đăng nhập")
        }

        LaunchedEffect(registerState) {
            registerState?.let {
                it.fold(
                    onSuccess = {
                        Log.d("Register", "Đăng ký thành công! Yêu cầu xác nhận email.")
                        Toast.makeText(context, "Vui lòng kiểm tra email để xác nhận!", Toast.LENGTH_SHORT).show()
                        navController.navigate("verify_email") {
                            popUpTo("register") { inclusive = true }
                        }
                        // Clear the state after navigation
                        authViewModel.clearRegisterState()
                    },
                    onFailure = { error ->
                        Log.d("Register", "Đăng ký thất bại: ${error.message}")
                        Toast.makeText(context, error.message ?: "Đăng ký thất bại!", Toast.LENGTH_SHORT).show()
                        // Clear state on failure too
                        authViewModel.clearRegisterState()
                    }
                )
            }
        }
    }
}
