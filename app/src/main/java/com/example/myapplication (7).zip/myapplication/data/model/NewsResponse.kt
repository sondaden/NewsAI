package com.example.myapplication.data.model

data class NewsResponse(
    val results: List<NewsArticle>?
)