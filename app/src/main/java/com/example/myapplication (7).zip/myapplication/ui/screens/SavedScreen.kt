package com.example.myapplication.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.myapplication.ui.components.BottomNavigationBar
import com.example.myapplication.ui.components.ReusableTabBar
import com.example.myapplication.ui.components.TopBar
import com.example.myapplication.ui.theme.NewsAppTheme
import com.example.myapplication.viewmodel.SavedViewModel

@Composable
fun SavedArticlesScreen(navController: NavController) {
    val savedViewModel = remember { SavedViewModel() }
    var isDarkTheme by remember { mutableStateOf(false) }
    var selectedItem by remember { mutableStateOf("Đã lưu") }

    NewsAppTheme(darkTheme = isDarkTheme) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Thanh TopBar
            TopBar(
                titleContent = {
                    Text(
                        text = "Đã lưu",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                },
                actions = {
                    IconButton(onClick = { /* Xử lý menu */ }) {
                        Icon(
                            Icons.Default.MoreVert,
                            contentDescription = "Menu",
                            tint = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            )

            // Nội dung chính
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                val savedTabs = listOf("Chủ đề", "Nguồn", "Tin tức")
                ReusableTabBar(tabTitles = savedTabs) { page ->
                    when (page) {
                        0 -> SavedTopicsContent(navController, savedViewModel)
                        1 -> SavedSourcesContent(navController, savedViewModel)
                        2 -> SavedNewsContent(navController, savedViewModel)
                    }
                }
            }

            // Thanh BottomNavigationBar
            BottomNavigationBar(
                selectedItem = selectedItem,
                onItemSelected = { item ->
                    selectedItem = item
                    navController.navigate(item.lowercase()) {
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    }
}

@Composable
fun SavedTopicsContent(navController: NavController, viewModel: SavedViewModel) {
//    val savedTopics by viewModel.savedTopics.collectAsState()
//
//    LazyColumn(
//        modifier = Modifier
//            .fillMaxSize()
//            .padding(horizontal = 16.dp)
//    ) {
//        item {
//            Text(
//                text = "Chủ đề đã lưu",
//                style = MaterialTheme.typography.headlineMedium,
//                modifier = Modifier.padding(vertical = 16.dp)
//            )
//        }
//
//        items(savedTopics) { topic ->
//            Card(
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .padding(vertical = 8.dp)
//                    .clickable { /* Navigate to topic detail */ },
//                colors = CardDefaults.cardColors(
//                    containerColor = MaterialTheme.colorScheme.surface
//                )
//            ) {
//                Row(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .padding(16.dp),
//                    horizontalArrangement = Arrangement.SpaceBetween,
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    Text(
//                        text = topic,
//                        style = MaterialTheme.typography.titleMedium
//                    )
//
//                    IconButton(onClick = { /* Remove from saved */ }) {
//                        Icon(
//                            Icons.Default.Bookmark,
//                            contentDescription = "Đã lưu",
//                            tint = MaterialTheme.colorScheme.primary
//                        )
//                    }
//                }
//            }
//        }
//    }
}

@Composable
fun SavedSourcesContent(navController: NavController, viewModel: SavedViewModel) {
//    val savedSources by viewModel.savedSources.collectAsState()
//
//    LazyColumn(
//        modifier = Modifier
//            .fillMaxSize()
//            .padding(horizontal = 16.dp)
//    ) {
//        item {
//            Text(
//                text = "Nguồn đã lưu",
//                style = MaterialTheme.typography.headlineMedium,
//                modifier = Modifier.padding(vertical = 16.dp)
//            )
//        }
//
//        items(savedSources) { source ->
//            Card(
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .padding(vertical = 8.dp)
//                    .clickable { /* Navigate to source detail */ },
//                colors = CardDefaults.cardColors(
//                    containerColor = MaterialTheme.colorScheme.surface
//                )
//            ) {
//                Row(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .padding(16.dp),
//                    horizontalArrangement = Arrangement.SpaceBetween,
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    Text(
//                        text = source,
//                        style = MaterialTheme.typography.titleMedium
//                    )
//
//                    IconButton(onClick = { /* Remove from saved */ }) {
//                        Icon(
//                            Icons.Default.Bookmark,
//                            contentDescription = "Đã lưu",
//                            tint = MaterialTheme.colorScheme.primary
//                        )
//                    }
//                }
//            }
//        }
//    }
}

@Composable
fun SavedNewsContent(navController: NavController, viewModel: SavedViewModel) {
//    val articles by viewModel.savedArticles.collectAsState()
//
//    LazyColumn(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(MaterialTheme.colorScheme.background)
//    ) {
//        items(articles) { article ->
//            NewsArticleItem(article, onClick = { navController.navigate("detail/${article.id}") })
//            HorizontalDivider(
//                modifier = Modifier.padding(horizontal = 12.dp),
//                thickness = 0.5.dp,
//                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f)
//            )
//        }
//
//        if (articles.isEmpty()) {
//            item {
//                Box(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .height(400.dp),
//                    contentAlignment = Alignment.Center
//                ) {
//                    Text("Chưa có tin tức nào được lưu")
//                }
//            }
//        }
//    }
}