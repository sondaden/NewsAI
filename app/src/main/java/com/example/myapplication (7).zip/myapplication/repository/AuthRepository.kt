package com.example.myapplication.repository

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.UUID

class AuthRepository(private val context: Context) {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    fun loginUser(email: String, password: String, onResult: (Result<String>) -> Unit) {
        if (email.isBlank() || password.isBlank()) {
            onResult(Result.failure(Exception("Email và mật khẩu không được để trống!")))
            return
        }

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user != null) {
                        if (!user.isEmailVerified) {
                            onResult(Result.failure(Exception("Tài khoản chưa xác minh email! Vui lòng kiểm tra email.")))
                        } else {
                            val deviceId = getDeviceId()
                            val userRef = firestore.collection("users").document(user.uid)

                            userRef.get().addOnSuccessListener { document ->
                                val existingDevices = (document.get("deviceIds") as? List<*>)?.mapNotNull { it as? String }?.toMutableList() ?: mutableListOf()
                                if (!existingDevices.contains(deviceId)) {
                                    existingDevices.add(deviceId)
                                }

                                userRef.update(
                                    "isLoggedIn", true,
                                    "deviceIds", existingDevices,
                                    "isEmailVerified", true
                                ).addOnSuccessListener {
                                    saveLoginState(true)
                                    onResult(Result.success("Đăng nhập thành công!"))
                                }.addOnFailureListener {
                                    onResult(Result.failure(Exception("Lỗi khi cập nhật trạng thái đăng nhập!")))
                                }
                            }
                        }
                    }
                } else {
                    onResult(Result.failure(Exception("Sai email hoặc mật khẩu!")))
                }
            }
    }

    fun registerUser(email: String, password: String, displayName: String, avatarUrl: String?, onResult: (Result<String>) -> Unit) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    user?.sendEmailVerification()?.addOnCompleteListener { emailTask ->
                        if (emailTask.isSuccessful) {
                            val userId = user.uid
                            val userData = hashMapOf(
                                "uid" to userId,
                                "email" to email,
                                "displayName" to displayName,
                                "avatarUrl" to avatarUrl,
                                "isEmailVerified" to false,
                                "isLoggedIn" to false,
                                "createdAt" to System.currentTimeMillis(),
                                "provider" to "email",
                                "favorites" to emptyList<String>(),
                                "savedArticles" to emptyList<String>(),
                                "followedSources" to emptyList<String>(),
                                "preferredTopics" to emptyList<String>()
                            )
                            firestore.collection("users").document(userId)
                                .set(userData)
                                .addOnSuccessListener {
                                    onResult(Result.success("Vui lòng kiểm tra email để xác nhận!"))
                                }
                                .addOnFailureListener {
                                    onResult(Result.failure(Exception("Lỗi khi tạo dữ liệu người dùng!")))
                                }
                        } else {
                            onResult(Result.failure(Exception("Không thể gửi email xác nhận!")))
                        }
                    }
                } else {
                    onResult(Result.failure(Exception(task.exception?.message ?: "Đăng ký thất bại!")))
                }
            }
    }

    fun logoutUser(onResult: (Result<String>) -> Unit) {
        val user = auth.currentUser
        if (user != null) {
            val deviceId = getDeviceId()
            val userRef = firestore.collection("users").document(user.uid)

            userRef.get().addOnSuccessListener { document ->
                val existingDevices = (document.get("deviceIds") as? List<*>)?.mapNotNull { it as? String }?.toMutableList() ?: mutableListOf()
                existingDevices.remove(deviceId)

                userRef.update(
                    "isLoggedIn", existingDevices.isNotEmpty(),
                    "deviceIds", existingDevices
                ).addOnSuccessListener {
                    auth.signOut()
                    saveLoginState(false)
                    onResult(Result.success("Đăng xuất thành công"))
                }.addOnFailureListener {
                    onResult(Result.failure(Exception("Lỗi khi đăng xuất!")))
                }
            }
        } else {
            saveLoginState(false)
            onResult(Result.success("Đăng xuất thành công"))
        }
    }

    fun checkLoginStatus(onResult: (Result<String>?) -> Unit) {
        try {
            if (isUserLoggedIn()) {
                onResult(Result.success("Đã đăng nhập (Offline)"))
            }

            val user = auth.currentUser
            if (user != null) {
                val deviceId = getDeviceId()
                firestore.collection("users").document(user.uid).get()
                    .addOnSuccessListener { document ->
                        try {
                            val storedDeviceIds = (document.get("deviceIds") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
                            val isLoggedIn = document.getBoolean("isLoggedIn") == true

                            if (isLoggedIn && storedDeviceIds.contains(deviceId)) {
                                saveLoginState(true)
                                onResult(Result.success("Đã đăng nhập (Online)"))
                            } else {
                                saveLoginState(false)
                                onResult(null)
                            }
                        } catch (_: Exception) {
                            onResult(null)
                        }
                    }
                    .addOnFailureListener {
                        onResult(null)
                    }
            } else {
                saveLoginState(false)
                onResult(null)
            }
        } catch (_: Exception) {
            onResult(null)
        }
    }

    fun checkEmailExists(email: String, callback: (Boolean) -> Unit) {
        firestore.collection("users")
            .whereEqualTo("email", email)
            .get()
            .addOnSuccessListener { result ->
                callback(!result.isEmpty)
            }
            .addOnFailureListener {
                callback(false)
            }
    }

    fun resendVerificationEmail(callback: (Boolean) -> Unit) {
        val user = auth.currentUser
        if (user != null) {
            user.sendEmailVerification()
                .addOnCompleteListener { task ->
                    callback(task.isSuccessful)
                }
        } else {
            callback(false)
        }
    }

    private fun saveLoginState(isLoggedIn: Boolean) {
        val sharedPreferences: SharedPreferences = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        sharedPreferences.edit {
            putBoolean("isLoggedIn", isLoggedIn)
        }
    }

    private fun isUserLoggedIn(): Boolean {
        val sharedPreferences: SharedPreferences = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        return sharedPreferences.getBoolean("isLoggedIn", false)
    }

    fun getDeviceId(): String {
        val sharedPreferences = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        var deviceId = sharedPreferences.getString("device_id", null)

        if (deviceId == null) {
            deviceId = UUID.randomUUID().toString()
            sharedPreferences.edit { putString("device_id", deviceId) }
        }

        return deviceId
    }
}