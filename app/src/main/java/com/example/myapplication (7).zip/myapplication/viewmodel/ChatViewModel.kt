package com.example.myapplication.viewmodel

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val isUser: Boolean)

class ChatViewModel : ViewModel() {
    private val _chatHistory = mutableStateOf(listOf(ChatMessage("Xin chào! Tôi có thể giúp gì cho bạn?", false)))
    val chatHistory: State<List<ChatMessage>> = _chatHistory

    fun sendMessage(message: String) {
        if (message.isNotBlank()) {
            // Thêm tin nhắn của người dùng
            _chatHistory.value = _chatHistory.value + ChatMessage("Bạn: $message", true)

            // Giả lập phản hồi từ chatbot
            viewModelScope.launch {
                delay(500) // Giả lập thời gian phản hồi
                val response = generateBotResponse(message)
                _chatHistory.value = _chatHistory.value + ChatMessage(response, false)
            }
        }
    }

    private fun generateBotResponse(userMessage: String): String {
        return when {
            userMessage.contains("news", ignoreCase = true) && userMessage.contains("AI", ignoreCase = true) -> {
                "The latest breakthrough in AI technology involves advanced language models that can now understand and generate human-like text with improved accuracy. Companies are implementing these systems for better customer service and automation."
            }
            userMessage.contains("hello", ignoreCase = true) || userMessage.contains("hi", ignoreCase = true) -> {
                "Hello! How can I help you today?"
            }
            else -> "I'm sorry, I don't have information on that topic. Can you ask something else?"
        }
    }
}