package com.example.myapplication.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.myapplication.ui.components.BottomNavigationBar
import com.example.myapplication.ui.components.TopBar
import com.example.myapplication.ui.theme.NewsAppTheme
import com.example.myapplication.viewmodel.ChatMessage
import com.example.myapplication.viewmodel.ChatViewModel
import androidx.compose.foundation.lazy.rememberLazyListState
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.Color
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.History
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Mic
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState

@Composable
fun ChatbotScreen(navController: NavController, chatViewModel: ChatViewModel = viewModel()) {
    var isDarkTheme by remember { mutableStateOf(false) }
    var selectedItem by remember { mutableStateOf("Chatbot") }
    var userInput by remember { mutableStateOf(TextFieldValue("")) }
    val chatHistory by chatViewModel.chatHistory

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(chatHistory) {
        if (chatHistory.isNotEmpty()) {
            listState.animateScrollToItem(chatHistory.size - 1)
        }
    }

    NewsAppTheme(darkTheme = isDarkTheme) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Thanh TopBar với icons lớn hơn
            TopBar(
                titleContent = {
                    Column {
                        Text(
                            text = "Chat bot",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                actions = {
                    Row {
                        IconButton(onClick = { /* Xử lý tạo chat mới */ }) {
                            Icon(
                                Icons.Default.Create,
                                contentDescription = "Tạo chat mới",
                                tint = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.size(28.dp) // Tăng kích thước icon
                            )
                        }
                        IconButton(onClick = { /* Xử lý xem lịch sử */ }) {
                            Icon(
                                Icons.Default.History,
                                contentDescription = "Lịch sử chat",
                                tint = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.size(28.dp) // Tăng kích thước icon
                            )
                        }
                    }
                }
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp)
                        .padding(top = 16.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 16.dp)
                    ) {
                        items(chatHistory) { message ->
                            ChatBubble(message)
                        }
                    }

                    // Thanh input với các icon mới
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Icon đính kèm tệp
                        IconButton(
                            onClick = { /* Xử lý đính kèm tệp */ }
                        ) {
                            Icon(
                                Icons.Default.AttachFile,
                                contentDescription = "Đính kèm",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // TextField với nút gửi và micro bên trong
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(24.dp))
                        ) {
                            TextField(
                                value = userInput,
                                onValueChange = { userInput = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Type a message...") },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    disabledIndicatorColor = Color.Transparent
                                ),
                                trailingIcon = {
                                    Box(modifier = Modifier.width(48.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.End,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            // Define animated values in composable context
                                            val microScale by animateFloatAsState(
                                                targetValue = if (userInput.text.isBlank()) 1f else 0.5f,
                                                animationSpec = tween(200, easing = FastOutSlowInEasing),
                                                label = "microScale"
                                            )
                                            val microAlpha = if (userInput.text.isBlank()) 1f else 0f

                                            val sendScale by animateFloatAsState(
                                                targetValue = if (userInput.text.isBlank()) 0.5f else 1f,
                                                animationSpec = tween(200, easing = FastOutSlowInEasing),
                                                label = "sendScale"
                                            )
                                            val sendAlpha = if (userInput.text.isBlank()) 0f else 1f

                                            // Stack both icons in exact same position
                                            Box(contentAlignment = Alignment.Center) {
                                                // Micro icon
                                                IconButton(
                                                    onClick = { /* Xử lý micro */ },
                                                    modifier = Modifier.graphicsLayer {
                                                        scaleX = microScale
                                                        scaleY = microScale
                                                        alpha = microAlpha
                                                    },
                                                    colors = IconButtonDefaults.iconButtonColors(
                                                        containerColor = Color.Transparent,
                                                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                ) {
                                                    Icon(
                                                        Icons.Default.Mic,
                                                        contentDescription = "Micro",
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }

                                                // Send button
                                                IconButton(
                                                    onClick = {
                                                        if (userInput.text.isNotBlank()) {
                                                            chatViewModel.sendMessage(userInput.text)
                                                            userInput = TextFieldValue("")
                                                            coroutineScope.launch {
                                                                listState.animateScrollToItem(chatHistory.size)
                                                            }
                                                        }
                                                    },
                                                    modifier = Modifier.graphicsLayer {
                                                        scaleX = sendScale
                                                        scaleY = sendScale
                                                        alpha = sendAlpha
                                                    },
                                                    colors = IconButtonDefaults.iconButtonColors(
                                                        containerColor = Color.Transparent,
                                                        contentColor = MaterialTheme.colorScheme.primary
                                                    )
                                                ) {
                                                    Icon(
                                                        Icons.AutoMirrored.Filled.Send,
                                                        contentDescription = "Gửi",
                                                        tint = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }

            BottomNavigationBar(
                selectedItem = selectedItem,
                onItemSelected = { item ->
                    selectedItem = item
                    navController.navigate(item.lowercase()) {
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (message.isUser) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.surface
                )
                .padding(12.dp)
                .widthIn(max = 280.dp)
        ) {
            Text(
                text = message.text.removePrefix("Bạn: "),
                style = MaterialTheme.typography.bodyMedium,
                color = if (message.isUser) MaterialTheme.colorScheme.onPrimary
                else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}