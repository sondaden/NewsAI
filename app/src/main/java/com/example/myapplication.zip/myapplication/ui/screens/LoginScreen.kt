package com.example.myapplication.ui.screens

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.myapplication.viewmodel.AuthViewModel
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun LoginScreen(navController: NavController, authViewModel: AuthViewModel) {
    val email = remember { mutableStateOf("") }
    val password = remember { mutableStateOf("") }
    val context = LocalContext.current

    Column {
        TextField(value = email.value, onValueChange = { email.value = it }, label = { Text("Email") })
        TextField(value = password.value, onValueChange = { password.value = it }, label = { Text("Mật khẩu") }, visualTransformation = PasswordVisualTransformation())

        Button(onClick = {
            authViewModel.login(email.value, password.value,
                onSuccess = {
                    navController.navigate("home") { popUpTo("login") { inclusive = true } }
                },
                onFailure = { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
            )
        }) {
            Text("Đăng nhập")
        }
    }
}

fun updateLoginStatus(userId: String, status: Boolean) {
    val db = FirebaseFirestore.getInstance()
    db.collection("users").document(userId)
        .update("is_logged_in", status)
        .addOnSuccessListener {
            Log.d("Firestore", "Cập nhật trạng thái đăng nhập thành công")
        }
        .addOnFailureListener { e ->
            Log.e("Firestore", "Lỗi khi cập nhật trạng thái", e)
        }
}