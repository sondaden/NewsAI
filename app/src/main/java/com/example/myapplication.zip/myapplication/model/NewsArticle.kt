package com.example.myapplication.model

import com.google.gson.annotations.SerializedName

data class NewsArticle(
    @SerializedName("article_id") val id: String,
    @SerializedName("title") val title: String,
    @SerializedName("content") val content: String?,
    @SerializedName("source_id") val source: String,
    @SerializedName("creator") val author: List<String>?,
    @SerializedName("pubDate") val publishedAt: String,
    @SerializedName("image_url") val imageUrl: String?,
    @SerializedName("category") val category: List<String>,

    val isBookmarked: Boolean = false, // Mặc định là chưa lưu

    // Các thuộc tính do AI hỗ trợ (Chưa có trong API, cần tính toán riêng)
    val aiGeneratedSummary: String? = null,
    val sentiment: String? = null,
    val relevanceScore: Float? = null,

    // Độ tin cậy (Chưa có trong API, cần tính toán riêng)
    val reliabilityScore: Float? = null
)