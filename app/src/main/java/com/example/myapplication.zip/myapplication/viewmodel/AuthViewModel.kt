package com.example.myapplication.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.repository.AuthRepository
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AuthViewModel(context: Context) : ViewModel() {
    private val authRepository = AuthRepository(context)

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn

    fun checkLoginStatus() {
        viewModelScope.launch {
            _isLoggedIn.value = authRepository.isUserLoggedIn()
        }
    }

    fun login(email: String, password: String, onSuccess: (FirebaseUser) -> Unit, onFailure: (String) -> Unit) {
        viewModelScope.launch {
            val user = authRepository.login(email, password)
            if (user != null) {
                _isLoggedIn.value = true
                onSuccess(user)
            } else {
                onFailure("Email hoặc mật khẩu không đúng")
            }
        }
    }

    fun register(email: String, password: String, onSuccess: (FirebaseUser) -> Unit, onFailure: (String) -> Unit) {
        viewModelScope.launch {
            val user = authRepository.register(email, password)
            if (user != null) {
                _isLoggedIn.value = true
                onSuccess(user)
            } else {
                onFailure("Đăng ký thất bại")
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
            _isLoggedIn.value = false
        }
    }
}
