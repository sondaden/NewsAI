package com.example.myapplication.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import com.example.myapplication.ui.components.BottomNavigationBar
import com.example.myapplication.ui.components.ReusableTabBar
import com.example.myapplication.ui.components.SectionContent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedArticlesScreen(navController: NavController) {
    val savedTabs = listOf("Chủ đề", "Nguồn", "Tin tức")

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Đã lưu") })
        },
        bottomBar = {
            BottomNavigationBar(selectedItem = "saved", onItemSelected = { navController.navigate(it) })
        }
    ) { paddingValues ->
        Column(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            ReusableTabBar(tabTitles = savedTabs) { page ->
                when (page) {
                    0 -> SavedTopicsContent()
                    1 -> SavedSourcesContent()
                    2 -> SavedNewsContent()
                }
            }
        }
    }
}

@Composable
fun SavedTopicsContent() {
    SectionContent("Danh sách chủ đề đã lưu")
}

@Composable
fun SavedSourcesContent() {
    SectionContent("Danh sách nguồn đã lưu")
}

@Composable
fun SavedNewsContent() {
    SectionContent("Danh sách tin tức đã lưu")
}
