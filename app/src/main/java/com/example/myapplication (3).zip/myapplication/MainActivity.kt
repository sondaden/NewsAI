package com.example.myapplication

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.myapplication.ui.screens.*
import com.example.myapplication.ui.theme.NewsAppTheme
import androidx.activity.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.viewmodel.NewsViewModel
import com.example.myapplication.repository.NewsRepository
import com.example.myapplication.viewmodel.AuthViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
  private val newsRepository = NewsRepository()
  private val newsViewModel: NewsViewModel by viewModels { NewsViewModelFactory(newsRepository) }
  private val auth = FirebaseAuth.getInstance()
  private val db = FirebaseFirestore.getInstance()
  private val authViewModel: AuthViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    FirebaseApp.initializeApp(this)
    Log.d("Firebase", "Firebase đã được kết nối thành công!")

    setContent {
      val isLoggedIn = remember { mutableStateOf(false) }
      val isCheckingLogin = remember { mutableStateOf(true) }

      // Kiểm tra trạng thái đăng nhập từ Firestore
      LaunchedEffect(Unit) {
        val user = auth.currentUser
        if (user != null) {
          db.collection("users").document(user.uid).get()
            .addOnSuccessListener { document ->
              if (document.exists()) {
                isLoggedIn.value = document.getBoolean("is_logged_in") ?: false
              }
              isCheckingLogin.value = false
            }
            .addOnFailureListener {
              Log.e("Firestore", "Lỗi khi lấy trạng thái đăng nhập", it)
              isCheckingLogin.value = false
            }
        } else {
          isCheckingLogin.value = false
        }
      }

      if (!isCheckingLogin.value) {
        NewsApp(newsViewModel, isLoggedIn.value)
      }
    }
  }
}

@Composable
fun NewsApp(viewModel: NewsViewModel, isLoggedIn: Boolean) {
  val navController = rememberNavController()

  NavHost(navController = navController, startDestination = if (isLoggedIn) "home" else "login") {
    composable("login") { LoginScreen(navController) }
    composable("register") { RegisterScreen(navController) }
    composable("home") { HomeScreen(navController, viewModel) }
    composable("podcast") { PodcastScreen(navController) }
    composable("chatbot") { ChatbotScreen(navController) }
    composable("saved") { SavedArticlesScreen(navController) }
    composable("account") { AccountScreen(navController) }
    composable("detail/{articleId}") { backStackEntry ->
      val articleId = backStackEntry.arguments?.getString("articleId") ?: ""
      DetailScreen(articleId = articleId, onBack = { navController.popBackStack() })
    }
  }
}

class NewsViewModelFactory(private val repository: NewsRepository) : ViewModelProvider.Factory {
  override fun <T : ViewModel> create(modelClass: Class<T>): T {
    if (modelClass.isAssignableFrom(NewsViewModel::class.java)) {
      @Suppress("UNCHECKED_CAST")
      return NewsViewModel(repository) as T
    }
    throw IllegalArgumentException("Unknown ViewModel class")
  }
}
