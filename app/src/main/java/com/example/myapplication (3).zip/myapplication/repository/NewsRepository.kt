package com.example.myapplication.repository

import com.example.myapplication.model.NewsArticle
import android.util.Log

class NewsRepository {
    private val apiService = NewsApiService.create()

    suspend fun getNewsByCategory(category: String): List<NewsArticle> {
        val categoryMap = mapOf(
            "Mới nhất" to "top",
            "Công nghệ" to "technology",
            "Khoa học" to "science",
            "Thể thao" to "sports",
            "Giải trí" to "entertainment",
            "Sức khỏe" to "health"
        )

        val translatedCategory = categoryMap[category] ?: "top" // Mặc định là "Mới nhất"
        Log.d("NewsRepository", "Fetching news for category: $translatedCategory") // ✅ Debug log

        return try {
            val response = apiService.getNews(category = translatedCategory)
            Log.d("NewsRepository", "API Response: ${response.results}") // ✅ In dữ liệu trả về
            Log.d("NewsRepository", "Full API Response: $response") // ✅ Debug toàn bộ JSON phản hồi

            response.results ?: emptyList()
        } catch (e: Exception) {
            Log.e("NewsRepository", "API Error: ${e.message}", e) // ❌ Debug lỗi nếu có
            emptyList()
        }
    }
}

