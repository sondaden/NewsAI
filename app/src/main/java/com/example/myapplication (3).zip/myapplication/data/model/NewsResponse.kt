package com.example.myapplication.model

import com.google.gson.annotations.SerializedName

data class NewsResponse(
    val results: List<NewsArticle>?
)