package com.example.myapplication.model

import com.example.myapplication.data.model.NewsArticle

data class NewsResponse(
    val results: List<NewsArticle>?
)