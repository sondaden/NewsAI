package com.example.myapplication.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.model.NewsArticle
import com.example.myapplication.repository.NewsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class NewsViewModel(private val repository: NewsRepository) : ViewModel() {
  private val _articles = MutableStateFlow<List<NewsArticle>>(emptyList())
  val articles = _articles.asStateFlow()
  private var lastCategory: String? = null // Lưu danh mục đã tải

  fun fetchNews(category: String) {
    if (category == lastCategory && _articles.value.isNotEmpty()) return // Ngăn gọi API nhiều lần
    lastCategory = category

    viewModelScope.launch {
      _articles.value = repository.getNewsByCategory(category)
    }
  }
}

