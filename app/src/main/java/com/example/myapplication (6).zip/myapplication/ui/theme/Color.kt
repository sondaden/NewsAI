package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val LightPrimary = Color(0xFF6200EE)
val LightSecondary = Color(0xFF03DAC6)
val LightTertiary = Color(0xFFBB86FC)
val LightBackground = Color(0xFFF8F5F2)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEDEAE6)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightOnSecondary = Color(0xFF000000)
val LightOnBackground = Color(0xFF000000)
val LightOnSurface = Color(0xFF000000)
val LightOnSurfaceVariant = Color(0xFF5C5C5C)

// Dark Theme Colors (Updated with Orange Accent)
val DarkPrimary = Color(0xFFFFA726)
val DarkSecondary = Color(0xFF03DAC6)
val DarkTertiary = Color(0xFFFF9800)
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkSurfaceVariant = Color(0xFF2C2C2C)
val DarkOnPrimary = Color(0xFF000000)
val DarkOnSecondary = Color(0xFFFFFFFF)
val DarkOnBackground = Color(0xFFFFFFFF)
val DarkOnSurface = Color(0xFFFFFFFF)
val DarkOnSurfaceVariant = Color(0xFFB0B0B0)