package com.example.myapplication.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myapplication.viewmodel.AuthViewModel

@Composable
fun LoginScreen(navController: NavController, authViewModel: AuthViewModel = viewModel()) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    val loginState by authViewModel.loginState.observeAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Đăng nhập", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it; emailError = null },
            label = { Text("Email") },
            isError = emailError != null,
            singleLine = true
        )
        if (emailError != null) Text(emailError!!, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it; passwordError = null },
            label = { Text("Mật khẩu") },
            isError = passwordError != null,
            singleLine = true
        )
        if (passwordError != null) Text(passwordError!!, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                // Kiểm tra lỗi đầu vào trực tiếp
                emailError = when {
                    email.isBlank() -> "Email không được để trống"
                    !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() -> "Email không hợp lệ"
                    else -> null
                }

                passwordError = when {
                    password.isBlank() -> "Mật khẩu không được để trống"
                    password.length < 8 || !password.matches(".*[a-zA-Z].*".toRegex()) || !password.matches(".*\\d.*".toRegex()) ->
                        "Mật khẩu phải có ít nhất 8 ký tự gồm cả chữ và số!"
                    else -> null
                }

                // Chỉ đăng nhập khi không có lỗi
                if (emailError == null && passwordError == null) {
                    authViewModel.loginUser(email, password, context)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Đăng nhập")
        }

        Spacer(modifier = Modifier.height(16.dp))
        TextButton(onClick = { navController.navigate("register") }) {
            Text("Chưa có tài khoản? Đăng ký ngay")
        }

        LaunchedEffect(loginState) {
            loginState?.let { result ->
                result.fold(
                    onSuccess = {
                        Toast.makeText(context, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show()
                        navController.navigate("home") { popUpTo("login") { inclusive = true } }
                        authViewModel.clearLoginState() // Reset loginState sau khi xử lý
                    },
                    onFailure = { error ->
                        Toast.makeText(context, error.message ?: "Đăng nhập thất bại!", Toast.LENGTH_SHORT).show()
                        authViewModel.clearLoginState() // Thêm dòng này để tránh lỗi vòng lặp
                    }
                )
            }
        }
    }
}