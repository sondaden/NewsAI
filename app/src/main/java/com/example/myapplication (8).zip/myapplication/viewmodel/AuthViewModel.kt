package com.example.myapplication.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.model.UserProfile
import com.example.myapplication.repository.AuthRepository
import com.example.myapplication.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel quản lý logic xác thực người dùng (đăng nhập, đăng ký, đăng xuất) và thông tin hồ sơ.
 */
class AuthViewModel(
    private val authRepository: AuthRepository,
    private val userRepository: UserRepository
) : ViewModel() {

    // Trạng thái UI cho đăng nhập
    private val _loginState = MutableStateFlow<AuthUiState>(AuthUiState.Initial)
    val loginState: StateFlow<AuthUiState> = _loginState.asStateFlow()

    // Trạng thái UI cho đăng ký
    private val _registerState = MutableStateFlow<AuthUiState>(AuthUiState.Initial)
    val registerState: StateFlow<AuthUiState> = _registerState.asStateFlow()

    // Hồ sơ người dùng
    private val _userProfile = MutableStateFlow<UserProfile?>(null)
    val userProfile: StateFlow<UserProfile?> = _userProfile.asStateFlow()

    init {
        loadUserProfile()
    }

    /**
     * Đăng nhập người dùng bằng email và mật khẩu.
     * @param email Email người dùng.
     * @param password Mật khẩu người dùng.
     * @param context Context để truy cập SharedPreferences.
     */
    fun loginUser(email: String, password: String, context: Context) {
        viewModelScope.launch {
            _loginState.value = AuthUiState.Loading
            authRepository.loginUser(email, password) { result ->
                handleAuthResult(result, _loginState)
            }
        }
    }

    /**
     * Đăng ký người dùng mới.
     * @param email Email người dùng.
     * @param password Mật khẩu người dùng.
     * @param displayName Tên hiển thị của người dùng.
     * @param avatarUrl URL ảnh đại diện (có thể null).
     */
    fun registerUser(email: String, password: String, displayName: String, avatarUrl: String?) {
        viewModelScope.launch {
            _registerState.value = AuthUiState.Loading
            authRepository.registerUser(email, password, displayName, avatarUrl) { result ->
                handleAuthResult(result, _registerState) { uid ->
                    val userProfile = UserProfile(uid, displayName, email, avatarUrl)
                    viewModelScope.launch {
                        userRepository.updateUserProfile(userProfile).onSuccess {
                            _userProfile.value = userProfile
                        }
                    }
                }
            }
        }
    }

    /**
     * Đăng xuất người dùng.
     * @param context Context để truy cập SharedPreferences.
     */
    fun logoutUser(context: Context) {
        viewModelScope.launch {
            _loginState.value = AuthUiState.Loading
            authRepository.logoutUser { result ->
                handleAuthResult(result, _loginState) {
                    _userProfile.value = null
                }
            }
        }
    }

    /**
     * Kiểm tra trạng thái đăng nhập hiện tại.
     * @param context Context để truy cập SharedPreferences.
     */
    fun checkLoginStatus(context: Context) {
        viewModelScope.launch {
            _loginState.value = AuthUiState.Loading
            authRepository.checkLoginStatus { result ->
                handleAuthResult(result, _loginState)
            }
        }
    }

    /**
     * Gửi lại email xác thực cho người dùng hiện tại.
     * @param callback Hàm gọi lại trả về kết quả (true nếu thành công, false nếu thất bại).
     */
    fun resendVerificationEmail(callback: (Boolean) -> Unit) {
        authRepository.resendVerificationEmail(callback)
    }

    /**
     * Kiểm tra xem email đã tồn tại trong hệ thống chưa.
     * @param email Email cần kiểm tra.
     * @param callback Hàm gọi lại trả về kết quả (true nếu email đã tồn tại, false nếu chưa).
     */
    fun checkEmailExists(email: String, callback: (Boolean) -> Unit) {
        authRepository.checkEmailExists(email, callback)
    }

    /**
     * Lấy ID thiết bị duy nhất.
     * @param context Context để truy cập SharedPreferences.
     * @return Chuỗi ID thiết bị.
     */
    fun getDeviceId(context: Context): String = authRepository.getDeviceId()

    /**
     * Tải thông tin hồ sơ người dùng từ UserRepository.
     */
    private fun loadUserProfile() {
        viewModelScope.launch {
            userRepository.getUserProfile().fold(
                onSuccess = { _userProfile.value = it },
                onFailure = { _userProfile.value = null }
            )
        }
    }

    /**
     * Xử lý kết quả xác thực từ AuthRepository và cập nhật trạng thái UI.
     * @param result Kết quả từ AuthRepository (Result<String>).
     * @param stateFlow MutableStateFlow để cập nhật trạng thái UI.
     * @param onSuccess Hàm tùy chọn để xử lý khi thành công (nhận UID).
     */
    private fun handleAuthResult(
        result: Result<String>,
        stateFlow: MutableStateFlow<AuthUiState>,
        onSuccess: ((String) -> Unit)? = null
    ) {
        result.fold(
            onSuccess = { message ->
                viewModelScope.launch {
                    userRepository.getUserProfile().fold(
                        onSuccess = { profile -> _userProfile.value = profile },
                        onFailure = { _userProfile.value = null }
                    )
                }
                val uid = message.split(" ").lastOrNull() ?: "" // Giả sử UID nằm ở cuối message nếu có
                onSuccess?.invoke(uid)
                stateFlow.value = AuthUiState.Success(message)
            },
            onFailure = { exception ->
                stateFlow.value = AuthUiState.Error(exception.message ?: "Unknown error")
            }
        )
    }
}

/**
 * Trạng thái UI cho các tác vụ xác thực.
 */
sealed class AuthUiState {
    object Initial : AuthUiState() // Trạng thái ban đầu
    object Loading : AuthUiState() // Đang xử lý
    data class Success(val message: String) : AuthUiState() // Thành công với thông điệp
    data class Error(val message: String) : AuthUiState() // Lỗi với thông điệp
}