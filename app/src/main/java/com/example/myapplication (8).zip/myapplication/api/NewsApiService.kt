package com.example.myapplication.repository

import com.example.myapplication.data.model.NewsResponse
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Interface định nghĩa API lấy tin tức từ World News API.
 */
interface NewsApiService {
    /**
     * Lấy tin tức theo danh mục.
     * @param apiKey Khóa API (mặc định từ companion object).
     * @param query Từ khóa tìm kiếm (mặc định là tất cả).
     * @param category Danh mục tin tức (e.g., "technology").
     * @return NewsResponse chứa danh sách bài viết.
     */
    @GET("search-news")
    suspend fun getNews(
        @Query("api-key") apiKey: String = "YOUR_WORLD_NEWS_API_KEY",
        @Query("text") query: String = "*",
        @Query("category") category: String
    ): NewsResponse

    companion object {
        private const val BASE_URL = "https://api.worldnewsapi.com/"

        /**
         * Tạo instance của NewsApiService với logging.
         */
        fun create(): NewsApiService {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
            val client = OkHttpClient.Builder()
                .addInterceptor(logging)
                .build()
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(NewsApiService::class.java)
        }
    }
}