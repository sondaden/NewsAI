package com.example.myapplication.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.model.NewsArticle
import com.example.myapplication.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel quản lý dữ liệu và sở thích người dùng.
 * @param newsViewModel ViewModel cung cấp dữ liệu bài viết tin tức.
 * @param userRepository Repository quản lý dữ liệu người dùng.
 */
class UserViewModel(
    private val newsViewModel: NewsViewModel,
    private val userRepository: UserRepository
) : ViewModel() {

    // Lịch sử đọc
    private val _readingHistory = MutableStateFlow<List<NewsArticle>>(emptyList())
    val readingHistory: StateFlow<List<NewsArticle>> = _readingHistory.asStateFlow()

    // Danh sách bài viết đã lưu
    private val _savedArticles = MutableStateFlow<List<NewsArticle>>(emptyList())
    val savedArticles: StateFlow<List<NewsArticle>> = _savedArticles.asStateFlow()

    // Sở thích danh mục
    private val _preferences = MutableStateFlow<List<String>>(emptyList())
    val preferences: StateFlow<List<String>> = _preferences.asStateFlow()

    // Trạng thái chế độ tối
    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    init {
        loadUserData()
    }

    /**
     * Tải dữ liệu người dùng từ UserRepository.
     */
    fun loadUserData() {
        viewModelScope.launch {
            userRepository.getUserProfile().fold(
                onSuccess = { profile ->
                    _readingHistory.value = profile.readingHistory.mapNotNull { newsViewModel.getArticleById(it) }
                    _savedArticles.value = profile.savedArticles.mapNotNull { newsViewModel.getArticleById(it) }
                    _preferences.value = profile.preferences
                },
                onFailure = {
                    _readingHistory.value = emptyList()
                    _savedArticles.value = emptyList()
                    _preferences.value = emptyList()
                }
            )
            userRepository.getDarkThemePreference().fold(
                onSuccess = { _isDarkTheme.value = it },
                onFailure = { _isDarkTheme.value = false }
            )
        }
    }

    /**
     * Thêm bài viết vào lịch sử đọc.
     * @param articleId ID của bài viết cần thêm.
     */
    fun addToReadingHistory(articleId: String) {
        viewModelScope.launch {
            userRepository.addToReadingHistory(articleId).fold(
                onSuccess = {
                    val article = newsViewModel.getArticleById(articleId)
                    if (article != null) {
                        _readingHistory.value = (listOf(article) + _readingHistory.value).take(100)
                    }
                },
                onFailure = { /* Có thể thêm thông báo lỗi nếu cần */ }
            )
        }
    }

    /**
     * Xóa bài viết khỏi lịch sử đọc.
     * @param articleId ID của bài viết cần xóa.
     */
    fun removeFromReadingHistory(articleId: String) {
        viewModelScope.launch {
            userRepository.removeFromReadingHistory(articleId).fold(
                onSuccess = { _readingHistory.value = _readingHistory.value.filter { it.id != articleId } },
                onFailure = { /* Có thể thêm thông báo lỗi nếu cần */ }
            )
        }
    }

    /**
     * Xóa toàn bộ lịch sử đọc.
     */
    fun clearReadingHistory() {
        viewModelScope.launch {
            userRepository.getUserProfile().fold(
                onSuccess = { profile ->
                    userRepository.updateUserProfile(profile.copy(readingHistory = emptyList())).fold(
                        onSuccess = { _readingHistory.value = emptyList() },
                        onFailure = { /* Có thể thêm thông báo lỗi nếu cần */ }
                    )
                },
                onFailure = { /* Có thể thêm thông báo lỗi nếu cần */ }
            )
        }
    }

    /**
     * Thêm bài viết vào danh sách đã lưu.
     * @param articleId ID của bài viết cần thêm.
     */
    fun addToSavedArticles(articleId: String) {
        viewModelScope.launch {
            userRepository.addToSavedArticles(articleId).fold(
                onSuccess = {
                    val article = newsViewModel.getArticleById(articleId)
                    if (article != null) {
                        _savedArticles.value = _savedArticles.value + article
                    }
                },
                onFailure = { /* Có thể thêm thông báo lỗi nếu cần */ }
            )
        }
    }

    /**
     * Xóa bài viết khỏi danh sách đã lưu.
     * @param articleId ID của bài viết cần xóa.
     */
    fun removeFromSavedArticles(articleId: String) {
        viewModelScope.launch {
            userRepository.removeFromSavedArticles(articleId).fold(
                onSuccess = { _savedArticles.value = _savedArticles.value.filter { it.id != articleId } },
                onFailure = { /* Có thể thêm thông báo lỗi nếu cần */ }
            )
        }
    }

    /**
     * Cập nhật sở thích danh mục của người dùng.
     * @param preferences Danh sách sở thích mới.
     */
    fun updatePreferences(preferences: List<String>) {
        viewModelScope.launch {
            userRepository.updatePreferences(preferences).fold(
                onSuccess = { _preferences.value = preferences },
                onFailure = { /* Có thể thêm thông báo lỗi nếu cần */ }
            )
        }
    }

    /**
     * Chuyển đổi trạng thái chế độ tối.
     */
    fun toggleDarkTheme(userRepository: UserRepository) {
        viewModelScope.launch {
            val newValue = !_isDarkTheme.value
            userRepository.saveDarkThemePreference(newValue).fold(
                onSuccess = { _isDarkTheme.value = newValue },
                onFailure = { /* Có thể thêm thông báo lỗi nếu cần */ }
            )
        }
    }
}