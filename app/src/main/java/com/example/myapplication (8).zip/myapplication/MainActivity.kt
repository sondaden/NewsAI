package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.myapplication.repository.AuthRepository
import com.example.myapplication.repository.NewsRepository
import com.example.myapplication.repository.UserRepository
import com.example.myapplication.ui.navigation.AppNavigation
import com.example.myapplication.ui.theme.NewsAppTheme
import com.example.myapplication.viewmodel.AuthViewModel
import com.example.myapplication.viewmodel.AuthViewModelFactory
import com.example.myapplication.viewmodel.ChatViewModel
import com.example.myapplication.viewmodel.ChatViewModelFactory
import com.example.myapplication.viewmodel.NewsViewModel
import com.example.myapplication.viewmodel.NewsViewModelFactory
import com.example.myapplication.viewmodel.UserViewModel
import com.example.myapplication.viewmodel.UserViewModelFactory
import com.google.firebase.FirebaseApp

/**
 * Activity chính của ứng dụng, khởi tạo các ViewModel và thiết lập giao diện Compose.
 */
class MainActivity : ComponentActivity() {

  // Khởi tạo ViewModel với factory
  private val newsViewModel: NewsViewModel by viewModels {
    NewsViewModelFactory(NewsRepository())
  }
  private val authViewModel: AuthViewModel by viewModels {
    AuthViewModelFactory(AuthRepository(this), UserRepository(this))
  }
  private val userViewModel: UserViewModel by viewModels {
    UserViewModelFactory(
        UserRepository(this),
        newsViewModel = TODO()
    )
  }
  private val chatViewModel: ChatViewModel by viewModels {
    ChatViewModelFactory() // Giả sử không cần repository, tùy thuộc vào cách bạn định nghĩa ChatViewModel
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    FirebaseApp.initializeApp(this) // Khởi tạo Firebase
    enableEdgeToEdge() // Hỗ trợ giao diện edge-to-edge

    setContent {
      NewsAppTheme {
        AppNavigation(
          newsViewModel = newsViewModel,
          authViewModel = authViewModel,
          userViewModel = userViewModel,
          chatViewModel = chatViewModel
        )
      }
    }
  }
}