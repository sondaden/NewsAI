package com.example.myapplication.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.myapplication.data.model.NewsArticle
import com.example.myapplication.ui.components.AppScaffold
import com.example.myapplication.ui.components.BottomNavigationBar
import com.example.myapplication.ui.components.ReusableTabBar
import com.example.myapplication.ui.components.TopBar
import com.example.myapplication.viewmodel.UserViewModel
import kotlinx.coroutines.launch

/**
 * Màn hình hiển thị các bài viết, chủ đề và nguồn đã lưu của người dùng.
 * @param navController Điều khiển điều hướng giữa các màn hình.
 * @param userViewModel ViewModel quản lý dữ liệu người dùng.
 */
@Composable
fun SavedArticlesScreen(
    navController: NavController,
    userViewModel: UserViewModel
) {
    val savedArticles by userViewModel.savedArticles.collectAsState()
    val savedTopics by userViewModel.preferences.collectAsState()
    val savedSources by remember { derivedStateOf { savedArticles.mapNotNull { it.source }.distinct() } }
    val scope = rememberCoroutineScope()

    // Tải dữ liệu người dùng khi khởi tạo màn hình
    LaunchedEffect(Unit) {
        userViewModel.loadUserData() // Sửa từ loadUserProfile thành loadUserData
    }

    AppScaffold(
        topBar = {
            TopBar(titleContent = { Text("Đã lưu", style = MaterialTheme.typography.titleLarge) })
        },
        bottomBar = {
            BottomNavigationBar(
                selectedItem = "Đã lưu",
                onItemSelected = { route -> navController.navigate(route.lowercase()) }
            )
        }
    ) {
        ReusableTabBar(tabTitles = listOf("Chủ đề", "Nguồn", "Tin tức")) { page ->
            when (page) {
                0 -> SavedTopicsContent(savedTopics) { topic ->
                    scope.launch {
                        userViewModel.updatePreferences(savedTopics - topic) // Không cần userRepository
                    }
                }
                1 -> SavedSourcesContent(savedSources)
                2 -> SavedNewsContent(navController, savedArticles, userViewModel)
            }
        }
    }
}

/**
 * Hiển thị danh sách các chủ đề đã lưu.
 * @param topics Danh sách chủ đề.
 * @param onRemove Hàm gọi khi xóa một chủ đề.
 */
@Composable
fun SavedTopicsContent(topics: List<String>, onRemove: (String) -> Unit) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        if (topics.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Chưa có chủ đề nào được lưu")
                }
            }
        } else {
            items(topics) { topic ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(topic, style = MaterialTheme.typography.bodyLarge)
                        IconButton(onClick = { onRemove(topic) }) {
                            Icon(Icons.Default.BookmarkBorder, contentDescription = "Xóa")
                        }
                    }
                }
            }
        }
    }
}

/**
 * Hiển thị danh sách các nguồn đã lưu.
 * @param sources Danh sách nguồn.
 */
@Composable
fun SavedSourcesContent(sources: List<String>) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        if (sources.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Chưa có nguồn nào được lưu")
                }
            }
        } else {
            items(sources) { source ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(source, style = MaterialTheme.typography.bodyLarge)
                        IconButton(onClick = { /* TODO: Xóa nguồn */ }) {
                            Icon(Icons.Default.BookmarkBorder, contentDescription = "Xóa")
                        }
                    }
                }
            }
        }
    }
}

/**
 * Hiển thị danh sách các bài viết đã lưu.
 * @param navController Điều khiển điều hướng.
 * @param articles Danh sách bài viết đã lưu.
 * @param userViewModel ViewModel quản lý dữ liệu người dùng.
 */
@Composable
fun SavedNewsContent(
    navController: NavController,
    articles: List<NewsArticle>,
    userViewModel: UserViewModel
) {
    val scope = rememberCoroutineScope()
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        if (articles.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Chưa có tin tức nào được lưu")
                }
            }
        } else {
            items(articles) { article ->
                NewsArticleItem(
                    article = article,
                    onClick = { navController.navigate("detail/${article.id}") },
                    onRemove = {
                        scope.launch {
                            userViewModel.removeFromSavedArticles(article.id) // Không cần userRepository
                        }
                    }
                )
            }
        }
    }
}

/**
 * Hiển thị một bài viết trong danh sách đã lưu.
 * @param article Bài viết cần hiển thị.
 * @param onClick Hàm gọi khi nhấn vào bài viết.
 * @param onRemove Hàm gọi khi xóa bài viết.
 */
@Composable
fun NewsArticleItem(article: NewsArticle, onClick: () -> Unit, onRemove: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = article.title,
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${article.source} • ${article.publishedAt}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onRemove) {
                Icon(Icons.Default.BookmarkBorder, contentDescription = "Xóa")
            }
        }
    }
}