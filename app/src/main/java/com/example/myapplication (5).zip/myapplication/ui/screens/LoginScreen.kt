package com.example.myapplication.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myapplication.viewmodel.AuthViewModel

@Composable
fun LoginScreen(navController: NavController, authViewModel: AuthViewModel = viewModel()) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    val loginState by authViewModel.loginState.observeAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Đăng nhập", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it; emailError = null },
            label = { Text("Email") },
            isError = emailError != null,
            singleLine = true
        )
        if (emailError != null) Text(emailError!!, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it; passwordError = null },
            label = { Text("Mật khẩu") },
            isError = passwordError != null,
            singleLine = true
        )
        if (passwordError != null) Text(passwordError!!, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val isValid = validateInput(email, password,
                    onEmailError = { emailError = it },
                    onPasswordError = { passwordError = it }
                )
                if (isValid) authViewModel.loginUser(email, password, context)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Đăng nhập")
        }

        Spacer(modifier = Modifier.height(16.dp))
        TextButton(onClick = { navController.navigate("register") }) {
            Text("Chưa có tài khoản? Đăng ký ngay")
        }

        loginState?.let {
            it.fold(
                onSuccess = {
                    Toast.makeText(context, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show()
                    authViewModel.checkLoginStatus(context) // Cập nhật trạng thái đăng nhập
                    navController.navigate("home") { popUpTo("login") { inclusive = true } }
                },
                onFailure = { error ->
                    Toast.makeText(context, error.message ?: "Đăng nhập thất bại!", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}


/**
 * Kiểm tra dữ liệu nhập
 */
fun validateInput(email: String, password: String, onEmailError: (String) -> Unit, onPasswordError: (String) -> Unit): Boolean {
    var isValid = true

    if (email.isBlank()) {
        onEmailError("Email không được để trống")
        isValid = false
    } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
        onEmailError("Email không hợp lệ")
        isValid = false
    }

    if (password.isBlank()) {
        onPasswordError("Mật khẩu không được để trống")
        isValid = false
    } else if (password.length < 6) {
        onPasswordError("Mật khẩu phải có ít nhất 6 ký tự")
        isValid = false
    }

    return isValid
}

