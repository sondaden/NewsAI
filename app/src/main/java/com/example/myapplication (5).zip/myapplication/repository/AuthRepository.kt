package com.example.myapplication.repository

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class AuthRepository(private val context: Context) {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    // Lấy Device ID
    @SuppressLint("HardwareIds")
    private fun getDeviceId(): String {
        return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
    }

    // Đăng ký tài khoản mới
    suspend fun register(email: String, password: String): FirebaseUser? {
        return try {
            val result = auth.createUserWithEmailAndPassword(email, password).await()
            result.user?.let { user ->
                // Lưu thông tin user vào Firestore
                val userMap = hashMapOf(
                    "email" to email,
                    "logged_in_devices" to mapOf(getDeviceId() to true)
                )
                db.collection("users").document(user.uid).set(userMap).await()
                user
            }
        } catch (e: Exception) {
            Log.e("AuthRepository", "Lỗi đăng ký: ${e.message}")
            null
        }
    }

    // Đăng nhập tài khoản
    suspend fun login(email: String, password: String): FirebaseUser? {
        return try {
            val result = auth.signInWithEmailAndPassword(email, password).await()
            result.user?.let { user ->
                // Cập nhật trạng thái đăng nhập của thiết bị hiện tại
                db.collection("users").document(user.uid)
                    .update("logged_in_devices.${getDeviceId()}", true).await()
                user
            }
        } catch (e: Exception) {
            Log.e("AuthRepository", "Lỗi đăng nhập: ${e.message}")
            null
        }
    }

    // Kiểm tra thiết bị có đang đăng nhập không
    suspend fun isUserLoggedIn(): Boolean {
        val user = auth.currentUser ?: return false
        return try {
            val document = db.collection("users").document(user.uid).get().await()
            val loggedDevices = document.get("logged_in_devices") as? Map<*, *>
            loggedDevices?.containsKey(getDeviceId()) == true
        } catch (e: Exception) {
            Log.e("AuthRepository", "Lỗi kiểm tra đăng nhập: ${e.message}")
            false
        }
    }

    // Đăng xuất tài khoản trên thiết bị hiện tại
    suspend fun logout() {
        val user = auth.currentUser ?: return
        try {
            db.collection("users").document(user.uid)
                .update("logged_in_devices.${getDeviceId()}", FieldValue.delete()).await()
            auth.signOut()
        } catch (e: Exception) {
            Log.e("AuthRepository", "Lỗi đăng xuất: ${e.message}")
        }
    }
}
