package com.example.myapplication.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.TextFieldValue
import androidx.navigation.NavController
import com.example.myapplication.ui.components.BottomNavigationBar

@Composable
fun ChatbotScreen(navController: NavController) {
    var userInput by remember { mutableStateOf(TextFieldValue("")) }
    var chatHistory by remember { mutableStateOf(listOf("Xin chào! Tôi có thể giúp gì cho bạn?")) }

    Scaffold(
        bottomBar = { BottomNavigationBar(selectedItem = "chatbot", onItemSelected = { navController.navigate(it) }) }
    ) { paddingValues ->
        Column(
            modifier = Modifier.fillMaxSize().padding(paddingValues).padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Hiển thị lịch sử trò chuyện
            Column(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.Top
            ) {
                chatHistory.forEach { message ->
                    Text(text = message, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(4.dp))
                }
            }

            // Ô nhập tin nhắn
            Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = userInput,
                    onValueChange = { userInput = it },
                    modifier = Modifier.weight(1f).padding(8.dp)
                )
                Button(onClick = {
                    if (userInput.text.isNotBlank()) {
                        chatHistory = chatHistory + "Bạn: ${userInput.text}"
                        userInput = TextFieldValue("")
                    }
                }) {
                    Text("Gửi")
                }
            }
        }
    }
}
