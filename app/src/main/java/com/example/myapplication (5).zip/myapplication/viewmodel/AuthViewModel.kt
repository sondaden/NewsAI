package com.example.myapplication.viewmodel

import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import android.provider.Settings
import android.util.Log
import androidx.core.content.edit
import java.util.UUID

class AuthViewModel : ViewModel() {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    private val _loginState = MutableLiveData<Result<String>?>()
    val loginState: LiveData<Result<String>?> = _loginState

    private val _registerState = MutableLiveData<Result<String>?>()
    val registerState: LiveData<Result<String>?> = _registerState

    fun loginUser(email: String, password: String, context: Context) {
        if (email.isBlank() || password.isBlank()) {
            _loginState.value = Result.failure(Exception("Email và mật khẩu không được để trống!"))
            return
        }

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user != null) {
                        if (!user.isEmailVerified) {
                            _loginState.value = Result.failure(Exception("Tài khoản chưa xác minh email! Vui lòng kiểm tra email."))
                        } else {
                            val deviceId = getDeviceId(context)
                            val userRef = firestore.collection("users").document(user.uid)

                            userRef.get().addOnSuccessListener { document ->
                                val existingDevices = (document.get("deviceIds") as? List<*>)?.mapNotNull { it as? String }?.toMutableList() ?: mutableListOf()
                                if (!existingDevices.contains(deviceId)) {
                                    existingDevices.add(deviceId)
                                }

                                userRef.update(
                                    "isLoggedIn", true,
                                    "deviceIds", existingDevices,
                                    "isEmailVerified", true
                                ).addOnSuccessListener {
                                    _loginState.value = Result.success("Đăng nhập thành công!")
                                }.addOnFailureListener {
                                    _loginState.value = Result.failure(Exception("Lỗi khi cập nhật trạng thái đăng nhập!"))
                                }
                            }
                        }
                    }
                } else {
                    _loginState.value = Result.failure(Exception("Sai email hoặc mật khẩu!"))
                }
            }
    }

    fun clearLoginState() {
        _loginState.value = null
    }

    fun registerUser(email: String, password: String, displayName: String, avatarUrl: String?) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    user?.sendEmailVerification()?.addOnCompleteListener { emailTask ->
                        if (emailTask.isSuccessful) {
                            val userId = user.uid
                            val createdAt = System.currentTimeMillis()
                            val userData = hashMapOf(
                                "uid" to userId,
                                "email" to email,
                                "displayName" to displayName, // Sử dụng tên người dùng
                                "avatarUrl" to avatarUrl,
                                "isEmailVerified" to false,
                                "isLoggedIn" to false,
                                "createdAt" to createdAt,
                                "provider" to "email",
                                "favorites" to emptyList<String>(),
                                "savedArticles" to emptyList<String>(),
                                "followedSources" to emptyList<String>(),
                                "preferredTopics" to emptyList<String>()
                            )
                            firestore.collection("users").document(userId)
                                .set(userData)
                                .addOnSuccessListener {
                                    Log.d("Auth", "Người dùng được tạo thành công: $displayName")
                                    _registerState.value = Result.success("Vui lòng kiểm tra email để xác nhận!")
                                }
                                .addOnFailureListener { error ->
                                    Log.d("Auth", "Lỗi khi lưu dữ liệu người dùng: ${error.message}")
                                    _registerState.value = Result.failure(Exception("Lỗi khi tạo dữ liệu người dùng!"))
                                }
                        } else {
                            Log.d("Auth", "Lỗi khi gửi email xác nhận: ${emailTask.exception?.message}")
                            _registerState.value = Result.failure(Exception("Không thể gửi email xác nhận!"))
                        }
                    }
                } else {
                    Log.d("Auth", "Lỗi khi đăng ký: ${task.exception?.message}")
                    _registerState.value = Result.failure(Exception(task.exception?.message ?: "Đăng ký thất bại!"))
                }
            }
    }

    fun clearRegisterState() {
        _registerState.value = null
    }

    fun logoutUser(context: Context) {
        val user = auth.currentUser
        if (user != null) {
            val deviceId = getDeviceId(context)
            val userRef = firestore.collection("users").document(user.uid)

            userRef.get().addOnSuccessListener { document ->
                val existingDevices = (document.get("deviceIds") as? List<*>)?.mapNotNull { it as? String }?.toMutableList() ?: mutableListOf()
                existingDevices.remove(deviceId)

                userRef.update(
                    "isLoggedIn", existingDevices.isNotEmpty(),
                    "deviceIds", existingDevices
                ).addOnSuccessListener {
                    auth.signOut()
                    saveLoginState(context, false) // Cập nhật SharedPreferences
                    _loginState.value = null
                }.addOnFailureListener {
                    _loginState.value = Result.failure(Exception("Lỗi khi đăng xuất!"))
                }
            }
        }
    }

    fun checkLoginStatus(context: Context) {
        try {
            // 1️⃣ Kiểm tra trạng thái offline trước
            if (isUserLoggedIn(context)) {
                _loginState.postValue(Result.success("Đã đăng nhập (Offline)"))
            }

            // 2️⃣ Sau đó kiểm tra online để cập nhật chính xác hơn
            val user = auth.currentUser
            if (user != null) {
                val deviceId = getDeviceId(context)
                firestore.collection("users").document(user.uid).get()
                    .addOnSuccessListener { document ->
                        try {
                            val storedDeviceIds = (document.get("deviceIds") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
                            val isLoggedIn = document.getBoolean("isLoggedIn") ?: false

                            if (isLoggedIn && storedDeviceIds.contains(deviceId)) {
                                saveLoginState(context, true)
                                _loginState.postValue(Result.success("Đã đăng nhập (Online)"))
                            } else {
                                saveLoginState(context, false)
                                _loginState.postValue(null)
                            }
                        } catch (e: Exception) {
                            Log.e("AuthViewModel", "Error processing Firestore data: ${e.message}")
                            _loginState.postValue(null)
                        }
                    }
                    .addOnFailureListener { e ->
                        Log.e("AuthViewModel", "Firestore query failed: ${e.message}")
                        // Ensure we still set a value even on failure
                        _loginState.postValue(null)
                    }
            } else {
                saveLoginState(context, false)
                _loginState.postValue(null)
            }
        } catch (e: Exception) {
            Log.e("AuthViewModel", "Uncaught exception in checkLoginStatus: ${e.message}")
            _loginState.postValue(null)
        }
    }

    fun checkEmailExists(email: String, callback: (Boolean) -> Unit) {
        firestore.collection("users")
            .whereEqualTo("email", email)
            .get()
            .addOnSuccessListener { result ->
                callback(!result.isEmpty) // Nếu có kết quả -> Email đã tồn tại
            }
            .addOnFailureListener {
                callback(false) // Mặc định là chưa tồn tại nếu có lỗi
            }
    }

    fun resendVerificationEmail(callback: (Boolean) -> Unit) {
        val user = auth.currentUser
        if (user != null) {
            user.sendEmailVerification()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        callback(true)
                    } else {
                        Log.e("AuthViewModel", "Failed to resend verification email: ${task.exception?.message}")
                        callback(false)
                    }
                }
        } else {
            Log.e("AuthViewModel", "No user is signed in to resend verification")
            callback(false)
        }
    }

    private fun saveLoginState(context: Context, isLoggedIn: Boolean) {
        val sharedPreferences: SharedPreferences = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        sharedPreferences.edit {
            putBoolean("isLoggedIn", isLoggedIn)
            apply()
        }
    }

    private fun isUserLoggedIn(context: Context): Boolean {
        val sharedPreferences: SharedPreferences = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        return sharedPreferences.getBoolean("isLoggedIn", false)
    }

    private fun getDeviceId(context: Context): String {
        val sharedPreferences = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        var deviceId = sharedPreferences.getString("device_id", null)

        if (deviceId == null) {
            deviceId = UUID.randomUUID().toString()
            sharedPreferences.edit { putString("device_id", deviceId) }
        }

        return deviceId
    }
}
