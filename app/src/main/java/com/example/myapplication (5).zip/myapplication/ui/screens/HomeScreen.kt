package com.example.myapplication.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.myapplication.model.NewsArticle
import com.example.myapplication.repository.NewsRepository
import com.example.myapplication.ui.components.TopBar
import com.example.myapplication.ui.components.BottomNavigationBar
import com.example.myapplication.ui.components.ReusableTabBar
import com.example.myapplication.viewmodel.NewsViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController, viewModel: NewsViewModel) {
    var selectedItem by remember { mutableStateOf("Trang chủ") }
    val homeTabs = listOf("Mới nhất", "Công nghệ", "Khoa học", "Thể thao", "Giải trí", "Sức khỏe")

    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(
            onSearchClick = { /* Xử lý tìm kiếm */ },
            onMenuClick = { /* Xử lý menu */ }
        )

        Box(modifier = Modifier.weight(1f)) {
            ReusableTabBar(tabTitles = homeTabs) { page ->
                NewsListScreen(navController, viewModel, homeTabs[page])
            }
        }

        BottomNavigationBar(
            selectedItem = selectedItem,
            onItemSelected = { item ->
                selectedItem = item
                navController.navigate(item.lowercase()) {
                    launchSingleTop = true
                    restoreState = true
                }
            }
        )
    }
}

@Composable
fun NewsListScreen(navController: NavController, viewModel: NewsViewModel, category: String) {
    val articles by viewModel.articles.collectAsState()
    var isLoading by remember { mutableStateOf(false) }
    var currentPage by remember { mutableIntStateOf(1) } // Trang hiện tại

    LaunchedEffect(category) {
        isLoading = true
        viewModel.fetchNews(category)
        isLoading = false
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(articles) { article ->
            NewsArticleItem(article, onClick = { navController.navigate("detail/${article.id}") })
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
        }

        item {
            if (isLoading) {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                Button(onClick = {
                    isLoading = true
                    currentPage++
                    viewModel.fetchNews(category) // Cập nhật danh sách tin tức
                    isLoading = false
                }) {
                    Text("Tải thêm tin tức")
                }
            }
        }
    }
}


@Composable
fun NewsArticleItem(article: NewsArticle, onClick: () -> Unit) {
    Column(modifier = Modifier.clickable(onClick = onClick)) {
        Image(
            painter = rememberAsyncImagePainter(article.imageUrl),
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            contentScale = ContentScale.Crop
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = article.category.joinToString(", ") { it.uppercase() },
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )

        Text(
            text = article.title,
            style = MaterialTheme.typography.headlineSmall
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = article.source, style = MaterialTheme.typography.bodySmall)
            Text(text = article.publishedAt, style = MaterialTheme.typography.bodySmall)
        }
    }
}
