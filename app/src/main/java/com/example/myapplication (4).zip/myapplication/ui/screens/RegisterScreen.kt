package com.example.myapplication.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.compose.runtime.livedata.observeAsState
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myapplication.viewmodel.AuthViewModel

@Composable
fun RegisterScreen(navController: NavController, authViewModel: AuthViewModel = viewModel()) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    val registerState by authViewModel.registerState.observeAsState()

    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var confirmPasswordError by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Đăng ký", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it; emailError = null },
            label = { Text("Email") },
            isError = emailError != null,
            supportingText = { emailError?.let { Text(it) } }
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it; passwordError = null },
            label = { Text("Mật khẩu") },
            isError = passwordError != null,
            supportingText = { passwordError?.let { Text(it) } }
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it; confirmPasswordError = null },
            label = { Text("Xác nhận mật khẩu") },
            isError = confirmPasswordError != null,
            supportingText = { confirmPasswordError?.let { Text(it) } }
        )
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                emailError = if (email.isBlank()) "Email không được để trống!" else null
                passwordError = if (password.length < 8 || !password.matches(".*\\d.*".toRegex()))
                    "Mật khẩu phải có ít nhất 8 ký tự gồm cả chữ và số!"
                else null
                confirmPasswordError = if (password != confirmPassword) "Mật khẩu xác nhận không khớp!" else null

                if (emailError == null && passwordError == null && confirmPasswordError == null) {
                    authViewModel.registerUser(email, password)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Đăng ký")
        }

        Spacer(modifier = Modifier.height(16.dp))
        TextButton(onClick = { navController.navigate("login") }) {
            Text("Đã có tài khoản? Đăng nhập")
        }

        registerState?.let {
            it.fold(
                onSuccess = {
                    Toast.makeText(context, "Vui lòng kiểm tra email để xác nhận!", Toast.LENGTH_SHORT).show()
                    navController.navigate("verify_email") { popUpTo("register") { inclusive = true } }
                },
                onFailure = { error ->
                    Toast.makeText(context, error.message ?: "Đăng ký thất bại!", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}
