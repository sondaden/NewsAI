package com.example.myapplication.viewmodel

import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import androidx.core.content.edit // Sử dụng KTX extension

class AuthViewModel : ViewModel() {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    private val _loginState = MutableLiveData<Result<String>?>()
    val loginState: LiveData<Result<String>?> = _loginState

    private val _registerState = MutableLiveData<Result<String>?>()
    val registerState: LiveData<Result<String>?> = _registerState

    fun loginUser(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _loginState.value = Result.failure(Exception("Email và mật khẩu không được để trống!"))
            return
        }

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user != null) {
                        if (!user.isEmailVerified) {
                            _loginState.value = Result.failure(Exception("Tài khoản chưa xác minh email! Vui lòng kiểm tra email."))
                        } else {
                            saveLoginState(user.uid, true)
                            _loginState.value = Result.success("Đăng nhập thành công!")
                        }
                    } else {
                        _loginState.value = Result.failure(Exception("Lỗi khi lấy thông tin người dùng!"))
                    }
                } else {
                    _loginState.value = Result.failure(Exception("Sai email hoặc mật khẩu!"))
                }
            }
    }

    fun clearLoginState() {
        _loginState.value = null
    }

    fun registerUser(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    user?.sendEmailVerification()?.addOnCompleteListener { emailTask ->
                        _registerState.value = if (emailTask.isSuccessful) {
                            Result.success("Vui lòng kiểm tra email để xác nhận!")
                        } else {
                            Result.failure(Exception("Không thể gửi email xác nhận!"))
                        }
                    }
                } else {
                    _registerState.value = Result.failure(Exception(task.exception?.message ?: "Đăng ký thất bại!"))
                }
            }
    }

    fun clearRegisterState() {
        _registerState.value = null
    }

    fun logoutUser() {
        val user = auth.currentUser
        if (user != null) {
            saveLoginState(user.uid, false) // Truyền userId thay vì context
        }
        auth.signOut()
    }

    fun isUserLoggedIn(context: Context): Boolean {
        val sharedPreferences: SharedPreferences = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        return sharedPreferences.getBoolean("isLoggedIn", false)
    }

    private fun saveLoginState(userId: String, isLoggedIn: Boolean) {
        val userRef = firestore.collection("users").document(userId)
        userRef.update("isLoggedIn", isLoggedIn)
            .addOnSuccessListener { /* Thành công */ }
            .addOnFailureListener { /* Xử lý lỗi nếu cần */ }
    }
}
