package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val LightPrimary = Color(0xFF6200EE) // Màu chính
val LightSecondary = Color(0xFF03DAC6) // Màu phụ
val LightTertiary = Color(0xFFBB86FC) // Màu phụ thứ ba
val LightBackground = Color(0xFFF8F5F2) // Màu nền tổng thể
val LightSurface = Color(0xFFFFFFFF) // Màu nền thẻ bài viết
val LightSurfaceVariant = Color(0xFFEDEAE6) // Màu nền thanh tab
val LightOnPrimary = Color(0xFFFFFFFF) // Màu chữ trên nền chính
val LightOnSecondary = Color(0xFF000000) // Màu chữ trên nền phụ
val LightOnBackground = Color(0xFF000000) // Màu chữ trên nền tổng thể
val LightOnSurface = Color(0xFF000000) // Màu chữ trên nền thẻ bài viết
val LightOnSurfaceVariant = Color(0xFF5C5C5C) // Màu chữ tab chưa chọn

// Dark Theme Colors
val DarkPrimary = Color(0xFFBB86FC) // Màu chính
val DarkSecondary = Color(0xFF03DAC6) // Màu phụ
val DarkTertiary = Color(0xFF6200EE) // Màu phụ thứ ba
val DarkBackground = Color(0xFF121212) // Màu nền tổng thể
val DarkSurface = Color(0xFF1E1E1E) // Màu nền thẻ bài viết
val DarkSurfaceVariant = Color(0xFF2C2C2C) // Màu nền thanh tab trong dark mode
val DarkOnPrimary = Color(0xFF000000) // Màu chữ trên nền chính
val DarkOnSecondary = Color(0xFFFFFFFF) // Màu chữ trên nền phụ
val DarkOnBackground = Color(0xFFFFFFFF) // Màu chữ trên nền tổng thể
val DarkOnSurface = Color(0xFFFFFFFF) // Màu chữ trên nền thẻ bài viết
val DarkOnSurfaceVariant = Color(0xFFB0B0B0) // Màu chữ tab chưa chọn